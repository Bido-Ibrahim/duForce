# International Futures Network Diagram

Using Node.js and Express.js for the backend API, vanilla JavaScript and D3.js for the UI

### Frontend: Vanilla Javascript
1. Open a new terminal tab Install the dependencies
```
npm install
```

2. Run the command below to build the app and have the Vite build tool watch for changes
```
npm run autobuild
```

### Backend: Express.js
1. Run the server
```
node server.js
```

2. View the app on `http://localhost:8080/`

