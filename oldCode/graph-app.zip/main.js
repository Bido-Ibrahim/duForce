import ForceGraph  from './graph.js';

async function getData() {
  try {
    const params = {
      method: 'GET',
      mode: 'cors',
      headers: {
        'Content-Type': 'application/json',
      },
    }

    const [response1, response2] = await Promise.all([
      fetch('/nodes', params),
      fetch('/edges', params),
    ]);

    if (!response1.ok || !response2.ok) {
      throw new Error(`HTTP error! Status: ${response1.status} ${response2.status}`);
    }

    const resultNodes = await response1.json();
    const resultEdges = await response2.json();

    if (resultNodes && resultEdges) {
      
      const colors = [
        '#418BFC',
        '#46BCC8',
        '#D6AB1B',
        '#EB5E68',
        '#B6BE1C',
        '#F64D1A',
        '#BA6DE4',
        '#EA6BCB',
        '#B9AAC8',
        '#F08519',
      ];
      console.log(resultNodes)
      const resultNodesTrunc = resultNodes.map(d => {
        return {
          NAME: d.NAME,
          DEFINITION: d.DEFINITION,
          SUBMODULE: d.SUBMODULE,
          SUBMODULE_NAME: d['SUBMODULE NAME'],
          SEGMENT: d.SEGMENT,
          SEGMENT_NAME: d['SEGMENT NAME'],
          UNITS: d.UNITS,
          ReportValue: d.ReportValue
        }
      })
      // Execute the function to generate a new network
      ForceGraph(
        { nodes: resultNodesTrunc, links: resultEdges },
        {
          containerSelector: '#app',
          nodeId: 'NAME',
          sourceId: 'Variable',
          targetId: 'UsesVariable',
          nodeGroup: (d) => d.SUBMODULE,
          nodeTitle: (d) => d.NAME,
          linkStroke: '#fff',
          nodeStroke: '#000',
          linkStrokeWidth: 0.6,
          linkStrokeOpacity: 0.2,
          linkStroke: '#fff',
          labelFontWeight: (d) => (d.linkCnt >= 20 ? 'bold' : 'normal'),
          labelVisibility: (d) => (d.type === 'tier1' || d.type === 'tier2') ? 'visible' : 'hidden',
          labelColor: '#fff',
          colors,
          width: window.innerWidth,
          height: window.innerHeight,
        }
      );
    } else {
      throw new Error('Invalid response format');
    }
  } catch (error) {
    console.error('Error fetching data:', error);
  }
}

getData();

