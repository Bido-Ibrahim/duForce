const fs = require("fs");
const express = require("express")
const cors = require('cors')
const path = require("path")

const app = express()
app.use(cors())
const PORT = 8080

const sqlite3 = require("sqlite3").verbose();
const filepath = "./IFsVar.db";

const db = new sqlite3.Database(filepath);

app.use(function (req, res, next) {
  res.header("Access-Control-Allow-Origin", "*")
  res.header(
    "Access-Control-Allow-Headers",
    "Origin, X-Requested-With, Content-Type, Accept"
  )

  next()
})

app.get('/nodes', (req, res) => {
  //const title = req.query.title
  db.all(`SELECT * FROM ifsvar`, [], (error, rows) => {
    if (error) {
      throw new Error(error.message);
    }
    res.send(rows)
  });
})

app.get('/edges', (req, res) => {
  db.all(`SELECT * FROM varlink`, [], (error, rows) => {
    if (error) {
      throw new Error(error.message);
    }
    res.send(rows)
  });
})

app.use(express.static(path.join(__dirname, "dist")))

app.listen(PORT, "0.0.0.0", function onStart(err) {
  if (err) {
    console.log(err)
  }
  console.info(
    "==> 🌎 Listening on port %s. Open up http://0.0.0.0:%s/ in your browser.",
    PORT,
    PORT
  )
})