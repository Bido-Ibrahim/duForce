import * as d3 from 'd3';
import {bfsFromNode} from 'graphology-traversal';
import {dijkstra} from 'graphology-shortest-path';
import Graph from 'graphology';

function generatePath(d, exclude_radius) {
  var dx = d.target.x - d.source.x;
  var dy = d.target.y - d.source.y;
  var gamma = Math.atan2(dy, dx); // Math.atan2 returns the angle in the correct quadrant as opposed to Math.atan

  if (exclude_radius) {
    var sourceNewX = d.source.x + Math.cos(gamma) * d.source.r;
    var sourceNewY = d.source.y + Math.sin(gamma) * d.source.r;
    var targetNewX = d.target.x - Math.cos(gamma) * d.target.r;
    var targetNewY = d.target.y - Math.sin(gamma) * d.target.r;
  } else {
    var sourceNewX = d.source.x;
    var sourceNewY = d.source.y;
    var targetNewX = d.target.x;
    var targetNewY = d.target.y;
  }

  // Coordinates of mid point on line to add new vertex.
  let midX = (targetNewX - sourceNewX) / 2 + sourceNewX;
  let midY = (targetNewY - sourceNewY) / 2 + sourceNewY;
  return (
    'M' +
    sourceNewX +
    ',' +
    sourceNewY +
    'L' +
    midX +
    ',' +
    midY +
    'L' +
    targetNewX +
    ',' +
    targetNewY
  );
}

// Throttle function to limit the mouseover event frequency
function throttle(func, delay) {
  let timeout;
  return function() {
      if (!timeout) {
          func.apply(this, arguments);
          timeout = setTimeout(() => {
              timeout = null;
          }, delay);
      }
  };
}

export default function ForceGraph(
  {
    nodes, // an iterable of node objects (typically [{id}, …])
    links, // an iterable of link objects (typically [{source, target}, …])
  },
  {
    containerSelector,
    nodeId = 'id', // given d in nodes, returns a unique identifier (string)
    sourceId = 'source',
    targetId = 'target',
    nodeGroup, // given d in nodes, returns an (ordinal) value for color
    nodeGroups, // an array of ordinal values representing the node groups
    nodeTitle, // given d in nodes, a title string
    nodeFill = 'currentColor', // node stroke fill (if not using a group color encoding)
    nodeStroke = '#ffffff', // node stroke color
    nodeStrokeWidth = 1, // node stroke width, in pixels
    nodeFillOpacity = 1, // node stroke opacity
    nodeStrokeOpacity = 1, // node stroke opacity
    nodeRadius = 5, // node radius, in pixels
    linkStroke = '#000000', // link stroke color
    linkStrokeOpacity = 0.9, // link stroke opacity
    linkStrokeWidth = 1.5, // given d in links, returns a stroke width in pixels
    labelFontWeight = 'normal',
    labelVisibility = 'hidden',
    labelColor = '#000000',
    colors = d3.schemeTableau10, // an array of color strings, for the node groups
    width = 640, // outer width, in pixels
    height = 400, // outer height, in pixels
    tooltipStyles = {
      width: 'auto',
      height: 'auto',
      padding: '10px',
      'background-color': 'white',
      border: '1px solid black',
      'z-index': 10,
    }
  } = {}
) {

  createButtons()
  createSearch(nodes)
  
  // Initial states
  let timer
  let clicked = false
  let zoomLevel = 1
  let clickedNodes = []
  let expandedAll = true
  let showArrows = false
  let showNeighbors = false
  let searched = false

  // Set up accessors to enable a cleaner way of accessing data attributes
  const N = d3.map(nodes, (d) => d[nodeId]).map(intern);
  const LS = d3.map(links, (d) => d[sourceId]).map(intern);
  const LT = d3.map(links, (d) => d[targetId]).map(intern);

  // Replace the input nodes and links with mutable objects for the simulation
  nodes = d3.map(nodes, (d, i) => ({ id: N[i], ...d, type: 'tier3' }));
  links = d3.map(links, (_, i) => ({ source: LS[i], target: LT[i], type: 'tier3'}));

  const SUBMODULES = [...new Set(nodes.map(d => d.SUBMODULE))].filter(d => d).map(d => {
    return {
      id: 'submodule-' + d,
      NAME: d,
      SUBMODULE: d,
      type: 'tier1'
    }
  })

  const SEGMENTS = [...new Set(nodes.map(d => d.SUBMODULE + '_' + d.SEGMENT))].filter(d => d !== 'null_null').map(d => {
    return {
      id: 'segment-' + d,
      NAME: d,
      SUBMODULE: +d.split('_')[0],
      type: 'tier2'
    }
  })

  const SUBMODULE_SEGMENT_PAIR = [...new Set(nodes.map(d => d.SUBMODULE + '_' + d.SEGMENT))].filter(d => d !== 'null_null').map(d => {
    return {
      source: 'submodule-' + d.split('_')[0],
      target: 'segment-' + d,
      type: 'tier1'
    }
  })
  
  nodes = nodes.concat(SUBMODULES).concat(SEGMENTS)
  links = links.concat(SUBMODULE_SEGMENT_PAIR)

  const linkedByIndex = {};
  for (let i=0; i<links.length; i++){
    const link = links[i]
    linkedByIndex[`${link.source},${link.target}`] = 1;

    const srcNode = nodes.find(d => d.id === link.source)
    if(srcNode && srcNode['SEGMENT'] && link.source) {
      const source = 'segment-' + srcNode['SUBMODULE'] + '_' + srcNode['SEGMENT']
      if(linkedByIndex[`${source},${link.source}`] !== 1) {
        links.push({source, target: link.source, type: 'tier2'})
        linkedByIndex[`${source},${link.source}`] = 1;
      }
    } 
  };


  // necessary to calculate number of incoming connections to calculate node radius
  const linkCnt = d3
    .rollups(
      [...links.map((d) => d.source), ...links.map((d) => d.target)],
      (v) => v.length,
      (d) => d
    )
    .map((d) => ({ [d[0]]: d[1] }))
    .reduce((previous, current) => ({ ...previous, ...current }));

  nodes.forEach((d) => {
    d.linkCnt = linkCnt[d.id] || 0
  });

  // set up for filters in the future
  let origNodes = [...nodes]
  let origLinks = [...links]
  let showEle = {nodes, links}
  if(expandedAll === false) showEle = filterElements(nodes, links)
  console.log('update', showEle.nodes.length, showEle.links.length)
  const nodeRadiusScale = d3
    .scaleLinear()
    .domain([0, d3.max(nodes, (d) => d.linkCnt)])
    .range([4.5, 22])
    .clamp(true);

  /////////////////// Set up initial  DOM elements on screen ///////////////////
  const tooltip = d3
    .select('#app')
    .append('div')
    .attr('class', 'tooltip')
    .style('position', 'absolute')
    .style('visibility', 'hidden');

  for (const prop in tooltipStyles) {
    tooltip.style(prop, tooltipStyles[prop]);
  }
  const svg = d3
    .select(containerSelector)
    .append('svg')
    .attr('width', width)
    .attr('height', height)
    .attr('viewBox', [-width / 2, -height / 2, width, height])
    .attr('style', 'max-width: 100%; height: auto; pointer-events: auto;');

   svg
    .append('defs')
    .append('marker')
    .attr('id', 'arrowhead')
    .attr('viewBox', '-0 -5 10 10')
    .attr('refX', 0)
    .attr('refY', 0)
    .attr('orient', 'auto')
    .attr('markerWidth', 5)
    .attr('markerHeight', 5)
    .attr('xoverflow', 'visible')
    .append('svg:path')
    .attr('d', 'M 0,-5 L 10 ,0 L 0,5')
    .attr('fill', linkStroke)
    .style('stroke', 'none');

  const g = svg.append('g');

  const linkG = g
    .append('g')
    .attr('class', 'links')
    
  const nodeG = g
    .append('g')
    .attr('class', 'nodes')

  const textG = g
    .append('g')
    .attr('class', 'labels')

  //////////////////////////////////////////////////////////////////////////////

  /////////////////////////// add zoom capabilities ////////////////////////////
  const zoomHandler = d3.zoom().on('zoom', function (event) {
    g.attr('transform', event.transform);
    if (clicked) return;
    zoomLevel = event.transform.k;
    if (zoomLevel >= 3.5) {
      svg
        .selectAll('.label')
        .attr('visibility', (d) => (d.linkCnt >= 10 ? 'visible' : 'hidden'));
    } else if (zoomLevel >= 2) {
      svg
        .selectAll('.label')
        .attr('visibility', (d) => (d.linkCnt >= 20 ? 'visible' : 'hidden'));
    }
  });

  svg.call(zoomHandler);
  //////////////////////////////////////////////////////////////////////////////

  /////////////////////////// Run simulation on data ///////////////////////////
  const simulation = d3
    .forceSimulation()
    .force(
      'link',
      d3.forceLink().id((d) => d.id)
    )
    .force(
      'x',
      d3.forceX((d) => d.x)
    )
    .force(
      'y',
      d3.forceY((d) => d.y)
    )
    .force(
    'collision',
      d3.forceCollide().radius(function (d) {
        return (d.type === 'tier1' || d.type === 'tier2') ? 30 : null;
      })
    )
    .force("cluster", forceCluster().strength(0.8))

  update(showEle.nodes, showEle.links)
  //////////////////////////////////////////////////////////////////////////////

  /////////////////////// SIMULATION-RELATED FUNCTIONS /////////////////////////
  function update(nodes, links) {
    console.log('update', nodes, links)
    const T = nodeTitle === undefined ? d3.map(nodes, d => d.NAME).map(intern) : d3.map(nodes, nodeTitle).map(intern)
    const G = nodeGroup == null ? null : d3.map(nodes, nodeGroup).map(intern);
    const W = typeof linkStrokeWidth !== 'function' ? null : d3.map(links, linkStrokeWidth);
    const L = typeof linkStroke !== 'function' ? null : d3.map(links, linkStroke);
    if (G && nodeGroups === undefined) nodeGroups = d3.sort(G);
    const color = nodeGroup == null ? null : d3.scaleOrdinal(nodeGroups, colors);
      
    // Restart the force layout
    simulation
        .nodes(nodes)
        .force('link').links(links)
    
    simulation.force('charge', d3.forceManyBody().strength(expandedAll ? -50 : -100))

    simulation.on('tick', ticked);
        
    simulation
      .alpha(1)
      .restart();

    const graph = new Graph();

    nodes.forEach((n) => {
      if(!graph.hasNode(n.id)) graph.addNode(n.id);
    });
    links.forEach((e) => {
      if (graph.hasNode(e.source.id) && graph.hasNode(e.target.id)) {
        if (!graph.hasEdge(e.source.id, e.target.id)) {
          graph.addEdge(e.source.id, e.target.id);
        }
      }
    });
    
    // Update existing links
    const link = linkG.selectAll('path.link')
      .data(links)
      .join(
        enter => enter.append('path').attr('class', 'link'),
        update => update,
        exit => exit.remove()
      )
      .attr('stroke', typeof linkStroke !== 'function' ? linkStroke : null)
      .attr('stroke-width', typeof linkStrokeWidth !== 'function' ? linkStrokeWidth : null)
      .attr('stroke-opacity', (d) => (d.type === 'tier1' || d.type === 'tier2') ? 1 : linkStrokeOpacity)
      .attr('d', (d) => generatePath(d))
    
    if(showArrows){
      linkG.selectAll('path.link').attr('marker-mid', 'url(#arrowhead)');
    } 
    
    if (W) link.attr('stroke-width', (d, i) => W[i]);
    if (L) link.attr('stroke', (d, i) => L[i]);

    // Update existing nodes
    const updatedNode = nodeG.selectAll('.node')
      .data(nodes, d => d.id);
  
    updatedNode
      .join(
        enter => {
          const newNode = enter
            .append('g')
            .attr('class', 'node')
            .attr('pointer-events', 'auto')
            .attr('cursor', 'pointer')
            .attr('opacity', 1)
            .attr('transform', (d) => `translate(${d.x}, ${d.y})`)
            .call(drag(simulation))
            .on('click', function (event, dd) {
              event.preventDefault();
              if (event.detail === 1) {
                timer = setTimeout(() => {
                  if(clickedNodes.indexOf(dd.id) === -1) { // if the node is not already clicked
                    clickedNodes.push(dd.id)
                  } else {
                    clickedNodes.splice(dd.id, 1) // remove a clicked node if it is clicked again
                  }
                  console.log('clicked nodes', clickedNodes)
                  if(clickedNodes.length === 2){
                    const connectedNodes = dijkstra.bidirectional(graph, clickedNodes[0], clickedNodes[1]); // find shortest path between two nondes 
                    console.log('nodes that are stringed along the shortest path', connectedNodes)
                    if(connectedNodes){
                      highlightConnections(connectedNodes)
                    }
                    clicked = true
                  } else {
                    reset()
                    clicked = false
                  }
                  if(clickedNodes.length > 2) clickedNodes = []
                }, 200)
              }
            })
            .on('dblclick', function(event, dd){
              if (clicked || searched) return;
              event.preventDefault();
              clearTimeout(timer)
              console.log('double click to collapse/expand', dd)
              //expandableAction(dd)
              collapsibleAction(dd)
            })
            .on('mouseover', function(event, dd){
              if (clicked || searched || !showNeighbors) return;
              event.preventDefault();
              throttle(findNeighbours(graph, dd), 1000)
            })
            .on('mouseleave', function () {
              if (clicked || searched || !showNeighbors) return;
              reset()
            });

          newNode.append('circle')
            .attr('fill', nodeFill)
            .attr('stroke', nodeStroke)
            .attr('r', (d) => (d.type === 'tier1') ? 20 : (d.type === 'tier2') ? 12 : nodeRadiusScale(d.linkCnt))
            .attr('fill-opacity', nodeFillOpacity)
            .attr('stroke-opacity', nodeStrokeOpacity)
            .attr('stroke-width', nodeStrokeWidth);
            
          if (G)
            newNode
              .select('circle')
              .attr('fill', (d, i) => color(G[i]))
              .attr('stroke', nodeStroke)
      
          return newNode;
        },
        update => update,
        exit => exit.remove()
      );
  
    // Update existing text elements
    const updatedText = textG.selectAll('.label')
      .data(nodes, d => d.id);
  
    updatedText
      .join(
        enter => {
          const newText = enter
            .append('g')
            .attr('class', 'label')
            .attr('opacity', 1)
            .attr('transform', (d) => `translate(${d.x}, ${d.y})`)
            .attr('visibility', labelVisibility)
  
          newText.append('text')
            .attr('x', (d) => (d.type === 'tier1') ? 25 : (d.type === 'tier2') ? 17 : nodeRadiusScale(d.linkCnt) + 5)
            .attr('dominant-baseline', 'middle')
            .attr('text-anchor', 'start')
            .attr('fill', labelColor)
            .attr("stroke", "black")
            .attr("stroke-width", 0.2)
            .attr('font-size', (d) => (d.type === 'tier1' || d.type === 'tier2') ? 14 : Math.max(5, nodeRadiusScale(d.linkCnt)))
            .attr('font-weight', labelFontWeight)
            .text((d,i) => T[i]);

          return newText;
        },
        update => update,
        exit => exit.remove()
      );
  
    function ticked() {
      link.attr('d', (d) => generatePath(d));
      nodeG.selectAll('.node').attr('transform', (d) => `translate(${d.x}, ${d.y})`);
      textG.selectAll('.label').attr('transform', (d) => `translate(${d.x}, ${d.y})`);
    }
  }

  function drag(simulation) {
    function dragstarted(event, d) {
      if (!event.active) simulation.alphaTarget(0.3).restart();
      d.fx = d.x;
      d.fy = d.y;
    }

    function dragged(event, d) {
      d.fx = event.x;
      d.fy = event.y;
    }

    function dragended(event, d) {
      if (!event.active) simulation.alphaTarget(0);
      d.fx = null;
      d.fy = null;
    }

    return d3
      .drag()
      .on('start', dragstarted)
      .on('drag', dragged)
      .on('end', dragended);
  }

  function centroid(nodes) {
    let x = 0;
    let y = 0;
    let z = 0;
    for (const d of nodes) {
      let k = nodeRadiusScale(d.linkCnt) ** 2;
      x += d.x * k;
      y += d.y * k;
      z += k;
    }
    return {x: x / z, y: y / z};
  }
  
  function forceCluster() {
    var strength = 0.8;
    let nodes;
    function force(alpha) {
      const centroids = d3.rollup(nodes, centroid, nodeGroup);
      const l = alpha * strength;
      for (const d of nodes) {
        if(d.type !== 'tier1' && d.type !== 'tier2'){
          const {x: cx, y: cy} = centroids.get(d.SUBMODULE);
          d.vx -= (d.x - cx) * l;
          d.vy -= (d.y - cy) * l;
        }
      }
    }
    force.initialize = _ => nodes = _;
    force.strength = function(_) {
      return arguments.length ? (strength = +_, force) : strength;
    };
    return force;
  }
  //////////////////////////////////////////////////////////////////////////////

  /////////////////////// INTERACTION-RELATED FUNCTIONS ////////////////////////
  function filterElements(nodes, links, criteria, value, strict = true) {

    const nodesShow = nodes.filter(d => d.type === 'tier1' || d.type === 'tier2')
    const linksShow = links.filter(d => d.type === 'tier1')

    // const showNodesIDs = nodes
    //   .filter((d) => d[criteria] >= value)
    //   .map((d) => d[nodeId]);

    // if (strict) {
    //   const linksShow = links.filter(
    //     (d) =>
    //       showNodesIDs.indexOf(d.source.id) !== -1 &&
    //       showNodesIDs.indexOf(d.target.id) !== -1
    //   );

    //   return { nodes: showNodesIDs, links: linksShow };
    // } else {
    //   const linksShow = links.filter(
    //     (d) =>
    //       showNodesIDs.indexOf(d.source.id) !== -1 ||
    //       showNodesIDs.indexOf(d.target.id) !== -1
    //   );
    //   const nodesShow = linksShow
    //     .map((d) => d.source.id)
    //     .concat(linksShow.map((d) => d.target.id));
    //   return { nodes: nodesShow, links: linksShow };
    // }
      
    return { nodes: nodesShow, links: linksShow };
  }

  // Collapse children nodes back into a parent (only submodule or segment nodes) and re-render graph
  function collapsibleAction(d) {

    if(d.type !== 'tier1' && d.type !== 'tier2') return

    const nodeId = d.id
    const nodesToRemove = new Set();
    const linksToRemove = [];

    showEle.links.forEach((link) => {
      if (link.source.id === nodeId) {
        console.log(link.target.id)
        nodesToRemove.add(link.target.id);
        // remove links one degree away
        linksToRemove.push(link);
        // remove links second degree away
        let next_src_links = origLinks.filter(l => l.source.id === link.target.id)
        console.log(next_src_links)
        next_src_links.forEach((innerLink) => {
          if (innerLink.source.id !== nodeId) {
            nodesToRemove.add(innerLink.source.id);
          }
          linksToRemove.push(innerLink);
        })
        let next_target_links = origLinks.filter(l => l.target.id === link.target.id)
        console.log(next_target_links)
        next_target_links.forEach((innerLink) => {
          if (innerLink.target.id !== nodeId) {
            nodesToRemove.add(innerLink.target.id);
          }
          linksToRemove.push(innerLink);
        })
      }
    });

    // Use findIndex to find the index of the node object and remove it from array
    nodesToRemove.forEach((node) => {
      const nodeIndex = origNodes.findIndex((n) => n.id === node);
      if (nodeIndex !== -1) {
        showEle.nodes.splice(nodeIndex, 1);
      }
    });

    // Use findIndex to find the index of the link object and remove it from array
    linksToRemove.forEach((link) => {
      const linkIndex = origLinks.findIndex((l) => l.source.id === link.source.id && l.target.id === link.target.id);
      if (linkIndex !== -1) {
        showEle.links.splice(linkIndex, 1);
      }
    });
    console.log('collapse', nodesToRemove, linksToRemove, showEle.nodes.length, showEle.links.length)
    update(showEle.nodes, showEle.links); 
  }

  // Expand children nodes connected to a parent (any node) and re-render graph
  function expandableAction(d) {
    const nodeId = d.id
    const nodesToAdd = new Set();
    const linksToAdd = [];

    origLinks.forEach((link) => {
      if (link.source.id === nodeId) {
        nodesToAdd.add(link.target.id);
        linksToAdd.push(link);
        // add links second degree away
        let next_src_links = origLinks.filter(l => l.source.id === link.target.id)
        next_src_links.forEach((innerLink) => {
          if (innerLink.source.id !== nodeId) {
            nodesToAdd.add(innerLink.source.id);
          }
          linksToAdd.push(innerLink);
        })
        let next_target_links = origLinks.filter(l => l.target.id === link.target.id)
        next_target_links.forEach((innerLink) => {
          if (innerLink.target.id !== nodeId) {
            nodesToAdd.add(innerLink.target.id);
          }
          linksToAdd.push(innerLink);
        })
      }
    });

    // Use findIndex to find the index of the node object and add it to array
    nodesToAdd.forEach((node) => {
      const nodeIndex = origNodes.findIndex((n) => n.id === node);
      if (nodeIndex !== -1) {
        showEle.nodes.splice(nodeIndex, 0, origNodes.find(d => d.id === node));
      }
    });

    // Use findIndex to find the index of the link object and add it to array
    linksToAdd.forEach((link) => {
      const linkIndex = origLinks.findIndex((l) => l.source.id === link.source.id && l.target.id === link.target.id);
      if (linkIndex !== -1) {
        showEle.links.splice(linkIndex, 0, link);
      }
    });

    console.log('expand', nodesToAdd, linksToAdd, showEle.nodes.length, showEle.links.length)
    update(showEle.nodes, showEle.links); 
  }

  function findNeighbours(graph, dd){
    // Highlight the neighbors of the clicked node (up to 2 degrees away)
    let connectedNodes = [dd.id]
    bfsFromNode(graph, dd.id, function (node, attr, depth) {
      if (depth <= 2) {
        connectedNodes.push(node);
      }
    });
    highlightConnections(connectedNodes)   
    updateTooltip(dd)
  }
    
  function highlightNode(dd){
    nodeG.selectAll('.node')
      .attr('opacity', (d) => d.id == dd ? 1 : 0.2)

    linkG.selectAll('path.link')
      .attr('opacity', 0.1)

    textG.selectAll('.label')
      .attr('visibility', (d) => d.id == dd ? 'visible' : 'hidden');

  }

  function highlightConnections(connectedNodes) {
    nodeG.selectAll('.node')
      .attr('opacity', (d) => connectedNodes.indexOf(d.id) !== -1 ? 1 : 0);

    linkG.selectAll('path.link')
      .attr('opacity', (d) => (connectedNodes.indexOf(d.source.id) !== -1 && connectedNodes.indexOf(d.target.id) !== -1) ? 1 : 0);

    textG.selectAll('.label')
      .attr('visibility', (d) => connectedNodes.indexOf(d.id) !== -1 ? 'visible' : 'hidden');
  }

  function reset() {
    nodeG.selectAll('.node')
      .attr('opacity', 1)

    linkG.selectAll('path.link')
      .attr('opacity', 1)

    textG.selectAll('.label')
      .attr('visibility', labelVisibility);

    tooltip.style('visibility', 'hidden');
  }

  function updateTooltip(d) {
    let content = [];
    content.push(`<div><h3>${d.id}</h3></div>`); // tooltip title
    for (const [key, value] of Object.entries(d)) {
      // iterate over each attribute object and render
      if(key === 'fx' || key === 'fy' || key === 'vx' || key === 'vy' || key === 'x' || key === 'y') break
      content.push(`<div><b>${key}: </b><span>${value}</span></div>`);
    }
    let contentStr = '';
    content.map((d) => (contentStr += d));

    tooltip
      .html(`${contentStr}`)
      //.style('top', event.y - 300+ 'px') // adjust starting point of tooltip div to minimise chance of overlap with node
      //.style('left', event.x - 100 + 'px')
      .style('top', 120+ 'px') // adjust starting point of tooltip div to minimise chance of overlap with node
      .style('left', 5 + 'px')  
      .style('visibility', 'visible');
  }
  //////////////////////////////////////////////////////////////////////////////

  /////////////////////// HELPER FUNCTIONS ////////////////////////
  function intern(value) {
    return value !== null && typeof value === 'object'
      ? value.valueOf()
      : value;
  }

  function createButtons(){
    // Function to create a button element with a specified label and action
    function createButton(label, action) {
      const button = document.createElement("button");
      button.textContent = label;
      button.classList.add("button");
      button.addEventListener("click", action);
      return button;
    }
  
    // Function to perform an action when a button is clicked
    function buttonClickHandler(event) {
      const buttonId = event.target.getAttribute("data-button-id");
      
      // Check which button was clicked using its ID
      switch (buttonId) {
          case "button1":
            showArrows = !showArrows
            if(showArrows) {
              event.target.classList.add("clicked")
              linkG.selectAll('path.link').attr('marker-mid', 'url(#arrowhead)');
            } else {
              event.target.classList.remove("clicked")
              linkG.selectAll('path.link').attr('marker-mid', null);
            }
            break;
          case "button2":
            showNeighbors = !showNeighbors
            if(showNeighbors) {
              event.target.classList.add("clicked")
            } else {
              event.target.classList.remove("clicked")
            }
            break;
          case "button3":
            expandedAll = !expandedAll
            if(expandedAll) {
              update(nodes, links)
              event.target.classList.add("clicked")
            } else {
              event.target.classList.remove("clicked")
              showEle = filterElements(nodes, links)
              update(showEle.nodes, showEle.links)
            } 
            break;
          case "button4":
            reset()
            break;
          default:
            // Handle cases where an unknown button was clicked
            break;
      }
      
    }
  
    // Create an array of button labels
    const buttonLabels = ["Show directions", 'Show neighbors', "Expand All", 'Reset'];
  
    // Get the button panel element
    const buttonPanel = document.getElementById("buttonPanel");
  
    // Create and append buttons to the panel
    buttonLabels.forEach((label, index) => {
      const button = createButton(label, buttonClickHandler);
      button.setAttribute("data-button-id", `button${index + 1}`);
      if(index === 2) button.classList.add("clicked")
      buttonPanel.appendChild(button);
    });
  }

  function createSearch(variableData) {
    const searchInput = document.getElementById("search-input");
    const resetSearchIcon = document.getElementById("reset-search");
    const suggestionsContainer = document.getElementById("suggestions-container");

    // Function to filter suggestions based on user input
    function filterSuggestions(input) {
        return variableData.filter(item => {
            return item.NAME.toLowerCase().includes(input.toLowerCase()) ||
                item.DEFINITION.toLowerCase().includes(input.toLowerCase());
        });
    }

    // Function to update the suggestions dropdown
    function updateSuggestions(input) {
        const filteredSuggestions = filterSuggestions(input);
        suggestionsContainer.innerHTML = "";

        filteredSuggestions.forEach(item => {
            const suggestionElement = document.createElement("div");
            suggestionElement.classList.add("suggestion");
            suggestionElement.textContent = `${item.NAME} - ${item.DEFINITION}`;
            suggestionElement.addEventListener("click", () => {
                searched = true
                searchInput.value = item.NAME;
                suggestionsContainer.style.display = "none";
                resetSearchIcon.style.display = "block";
                console.log('searched node', item)
                highlightNode(item.NAME)
            });

            suggestionsContainer.appendChild(suggestionElement);
        });

        if (filteredSuggestions.length > 0) {
            suggestionsContainer.style.display = "block";
        } else {
            suggestionsContainer.style.display = "none";
        }
    }

    // Event listener for input changes
    searchInput.addEventListener("input", () => {
        const inputValue = searchInput.value;
        updateSuggestions(inputValue);
    });

    // Event listener for clicking the reset icon
    resetSearchIcon.addEventListener("click", () => {
      searched = false
      searchInput.value = "";
      suggestionsContainer.innerHTML = "";
      resetSearchIcon.style.display = "none";
      reset()
    });
  
    // Close suggestions when clicking outside
    document.addEventListener("click", (event) => {
        if (!suggestionsContainer.contains(event.target)) {
            suggestionsContainer.style.display = "none";
        }
    });
  }
  //////////////////////////////////////////////////////////////////
}
